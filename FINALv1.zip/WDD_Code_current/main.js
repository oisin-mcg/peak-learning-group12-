//game for javascript//oisin
	var player = document.getElementById("player");
	var block = document.getElementById("block");
	var counter=0;
	
//function to yeet the player div into the air 
	function jump(){
		if(player.classList == "animate"){return}
		player.classList.add("animate");
		//stops spamming so double clicks won't make you fly
		setTimeout(function(){
			player.classList.remove("animate");
		},300);
	}

	//checks if player has collided with the red X and prompts them to play again if they did
	var checkDead = setInterval(function() {
		let playerTop = parseInt(window.getComputedStyle(player).getPropertyValue("top"));
		let blockLeft = parseInt(window.getComputedStyle(block).getPropertyValue("left"));
		if(blockLeft<20 && blockLeft>-20 && playerTop>=302){
			block.style.animation = "none";
			alert("GAME OVER. Your score is!: "+Math.floor(counter/100));
			counter=0;
			block.style.animation = "block 1s infinite linear";
			block.style.display = "none";
			document.getElementById("scoreSpan").innerHTML="GAME OVER. Your score is!: "+Math.floor(counter/100);counter=0;
			if (confirm("Play again?")) {
			window.location.reload()
			}else {
			txt = "Okay!";
			}
			}else{
			counter++;
			document.getElementById("scoreSpan").innerHTML = Math.floor(counter/100);
			}
	}, 10);
	
//codepen tutorial I used to figure out how to implement my math random(https://codepen.io/omascaros/pen/LYeppN)
function randombg(){
  var random= Math.floor(Math.random() * 5) + 0;
  var bg = 	[
			 "url('images/sky.jpg')",
             "url('images/starry.jpg')",
			 "url('images/cloudy.jpg')",
             "url('images/water.jpg')",
             "url('images/cliffs.jpg')"
			 ];
  document.getElementById("game").style.backgroundImage=bg[random];
  
}

//define interval
const interval = 8000;

//function to repeat the blocks speed
function repeat() {
// Generate and define the obstacles speed 
  var randomSpeed = (Math.random() * 5) + 1;

// Apply speed to the block
  document.querySelector('#block').style.animationDuration = `${randomSpeed}s`;
}
//interval executer
const intervalId = setInterval(repeat, interval);



//Javascript for adams form/webpage//adam
 function validate(){
                //set valid to true - flag 
                var valid = true;
                var msge = "You have not fully completed the form, please fill in the following: ";
                //use if statements to check the data and set the message 
                if(document.getElementById("fn").value == ""){
                    msge += " You must fill in your firstname. ";
                    valid = false;
                }
                if(document.getElementById("sn").value == ""){
                    msge += " You must fill in your surname, ";
                    valid = false;
                }
                if(document.getElementById("cn").value == ""){
                    msge += " You must fill in your age, ";
                    valid = false;
                }
				if(document.getElementById("bn").value == ""){
                    msge += " You must fill in your email,";
                    valid = false;
                }
				if(document.getElementById("comments").value == ""){
                    msge += " You need to write your question in the comment box.";
                    valid = false;
                }
                if(!valid){ //!valid is the same as valid == false
                    document.getElementById("msge").innerHTML = msge;
                }
                return valid;
}

//javascript for gallery//dima
function hide(){
    document.getElementById('dima').style.display="hidden"
    document.getElementById('dima').innerHTML="Start learning in a comfortable environment for you. Online learning is more flexible and convenient. You have the opportunity to study at almost any time, at your own pace"
    document.getElementById('dima').style.fontSize="30"
    document.getElementById('dima').style.width="700"
    document.getElementById('dima').style.height="467"
    document.getElementById('dima').style.textAlign="left"
    document.getElementById('dima').style.backgroundColor="#fda93b"
    document.getElementById('dima').style.color="#ffffff"
    document.getElementById('dima').style.paddingLeft="10px"
}

function hide2(){
    document.getElementById('dima2').style.display="hidden"
    document.getElementById('dima2').innerHTML="Online learning can allow you to travel or fly away on vacation. Since you can study from anywhere, the main thing is to have access to the Internet."
    document.getElementById('dima2').style.fontSize="30"
    document.getElementById('dima2').style.width="700"
    document.getElementById('dima2').style.height="467"
    document.getElementById('dima2').style.textAlign="left"
    document.getElementById('dima2').style.backgroundColor="#fda93b"
    document.getElementById('dima2').style.color="#ffffff"
    document.getElementById('dima2').style.paddingLeft="10px"
}

function hide3(){
    document.getElementById('dima3').style.fontSize="30"
    document.getElementById('dima3').style.display="hidden"
    document.getElementById('dima3').innerHTML="Teamwork. It is difficult to call teamwork a plus of online learning, since work is more productive when meeting. But perhaps introverts will find it convenient to work in a team online."
    document.getElementById('dima3').style.width="700"
    document.getElementById('dima3').style.textAlign="left"
    document.getElementById('dima3').style.height="467"
    document.getElementById('dima3').style.backgroundColor="#fda93b"
    document.getElementById('dima3').style.color="#ffffff"
    document.getElementById('dima3').style.paddingLeft="10px"
}

function hide4(){
    document.getElementById('dima4').style.fontSize="30"
    document.getElementById('dima4').style.display="hidden"
    document.getElementById('dima4').innerHTML="for those who like to eat online, studying is a very big plus, since no one will reproach you for what you eat in front of the computer (but only if the webcam is turned off)"
    document.getElementById('dima4').style.width="700"
    document.getElementById('dima4').style.textAlign="left"
    document.getElementById('dima4').style.height="467"
    document.getElementById('dima4').style.backgroundColor="#fda93b"
    document.getElementById('dima4').style.color="#ffffff"
    document.getElementById('dima4').style.paddingLeft="10px"
}


//const interval2 = 2000;
//function repeat2() {
	//  document.getElementById('dima').style.backgroundImage="url('image/image1.jpg')"
	//  document.getElementById('dima2').style.backgroundImage="url('image/image2.jpg')"
	//  document.getElementById('dima3').style.backgroundImage="url('image/image3.jpg')"
	 // document.getElementById('dima4').style.backgroundImage="url('image/image4.jpg')"
//}

//const interval2Id = setInterval(repeat2, interval2);